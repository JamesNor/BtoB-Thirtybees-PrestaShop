<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_7b6e7f81d1c260b7068ca82b91eb90a7'] = 'Date d\'inscription';
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_d3b206d196cd6be3a2764c1fb90b200f'] = 'Supprimer la sélection';
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_53c6a96a3df980c3270d6ed82b6f174b'] = 'Voulez-vous supprimer les éléments sélectionner ?';
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_e22e6fdb76a82740864f7fe27e53a93d'] = 'Toutes les entreprises';
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_9a9aeb3ba5b33866c6344457fc9c8e6f'] = 'Voir l\'entreprise';
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_81f223f6627ed258abdcaeb5242971d1'] = 'Le supprimer';
$_MODULE['<{gsbtobs}prestashop>admingsbtobscontroller_0f7e7f998f845a05f78445fb60ce4ead'] = 'Êtes-vous sûr de vouloir supprimer ceci ?';
