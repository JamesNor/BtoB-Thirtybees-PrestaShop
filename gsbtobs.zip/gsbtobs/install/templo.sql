ALTER TABLE `PREFIX_customer`
DROP COLUMN id_company;

ALTER TABLE `PREFIX_customer`
ADD id_company int(11);
